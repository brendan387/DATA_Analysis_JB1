%%%plot all

clf
geoplot(WAY(:,1),WAY(:,2),'black -o')
hold on

geoplot(GPS1(:,1),GPS1(:,2))
geoplot(GPS2(:,1),GPS2(:,2))
geoplot(GPS3(:,1),GPS3(:,2))
geoplot(GPS4(:,1),GPS4(:,2))
geoplot(GPS5(:,1),GPS5(:,2))
geoplot(GPS6(:,1),GPS6(:,2))
geoplot(GPS7(:,1),GPS7(:,2))
geoplot(GPS8(:,1),GPS8(:,2))
geoplot(GPS9(:,1),GPS9(:,2))
geoplot(GPS10(:,1),GPS10(:,2))
geoplot(GPS11(:,1),GPS11(:,2))
geoplot(GPS12(:,1),GPS12(:,2))
