x = linspace(1,600);
y1 = (sin(x+26.5555455454)*5)+15;


y2 = cos(x+26.757757573434)*1.4345+12.678;

for row = 1:length(x)
    y1(:,row) = y1(:,row)*(0.95+(rand/10));
    y2(:,row) = y2(:,row)*(0.975+(rand/20));
end


plot(x,y1)
hold on
plot(x,y2)