


clearvars -except GPS1 GPS2 GPS3 GPS4 GPS5 GPS6 GPS8 GPS9 GPS10 GPS11 GPS12 WAY Error_Dist1 Error_Dist2 Error_Dist3 Error_Dist4 Error_Dist5 Error_Dist6 Error_Dist8 Error_Dist9 Error_Dist10 Error_Dist11 Error_Dist12