clf
%% find altitude
ST = 1000
ED = 5300

TEMP_GPS = GPS(ST:ED,9:10);
Time = GPS(:,2);
Alt = GPS(ST:ED,11)

geoplot(TEMP_GPS(:,1),TEMP_GPS(:,2),'red -')
hold on

geoplot(WAY(:,1),WAY(:,2),'black -o')

clearvars -except WAY GPS 