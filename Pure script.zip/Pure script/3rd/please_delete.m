
plot3(GPS1(:,1),GPS1(:,2),GPS1_Alt(:,1),'-')
hold on
plot3(WAY(:,1),WAY(:,2),WAY_Alt(:,1),'black-')
plot3(GPS2(:,1),GPS2(:,2),GPS2_Alt(:,1),'-')
plot3(GPS3(:,1),GPS3(:,2),GPS3_Alt(:,1),'-')
plot3(GPS4(:,1),GPS4(:,2),GPS4_Alt(:,1),'-')
plot3(GPS5(:,1),GPS5(:,2),GPS5_Alt(:,1),'-')
plot3(GPS6(:,1),GPS6(:,2),GPS6_Alt(:,1),'-')
plot3(GPS7(:,1),GPS7(:,2),GPS7_Alt(:,1),'-')
plot3(GPS8(:,1),GPS8(:,2),GPS8_Alt(:,1),'-')
plot3(GPS9(:,1),GPS9(:,2),GPS9_Alt(:,1),'-')
plot3(GPS10(:,1),GPS10(:,2),GPS10_Alt(:,1),'-')
plot3(GPS11(:,1),GPS11(:,2),GPS11_Alt(:,1),'-')
plot3(GPS12(:,1),GPS12(:,2),GPS12_Alt(:,1),'-')


%%waypoint number
% x = 1
% scatter3(XYZ1(:,1),XYZ1(:,2),XYZ1(:,3),'*')
% view(-30,10)
% hold on
% scatter3(0,0,0,'black*')
% scatter3(XYZ2(:,1),XYZ2(:,2),XYZ2(:,3),'*')
% scatter3(XYZ3(:,1),XYZ3(:,2),XYZ3(:,3),'*')
% scatter3(XYZ4(:,1),XYZ4(:,2),XYZ4(:,3),'*')
% scatter3(XYZ5(:,1),XYZ5(:,2),XYZ5(:,3),'*')
% scatter3(XYZ6(:,1),XYZ6(:,2),XYZ6(:,3),'*')
% scatter3(XYZ7(:,1),XYZ7(:,2),XYZ7(:,3),'*')
% scatter3(XYZ8(:,1),XYZ8(:,2),XYZ8(:,3),'*')
% scatter3(XYZ9(:,1),XYZ9(:,2),XYZ9(:,3),'*')
% scatter3(XYZ10(:,1),XYZ10(:,2),XYZ10(:,3),'*')
% scatter3(XYZ11(:,1),XYZ11(:,2),XYZ11(:,3),'*')
% scatter3(XYZ12(:,1),XYZ12(:,2),XYZ12(:,3),'*')