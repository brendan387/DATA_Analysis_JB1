clf

% plot(BASE(:,5),BASE(:,1),'r--','LineWidth',2)
% hold on
% plot(BASE(:,5),BASE(:,1),'ro','MarkerSize',7,'MarkerFaceColor','r')
% plot(ARSPD(:,5),ARSPD(:,1),'b-','LineWidth',2)
% plot(ARSPD(:,5),ARSPD(:,1),'bo','MarkerSize',7,'MarkerFaceColor','b')
% plot(DUAL(:,5),DUAL(:,1),'g-.','LineWidth',2)
% plot(DUAL(:,5),DUAL(:,1),'go','MarkerSize',7,'MarkerFaceColor','g')
% title('Waypoint Accuracy on Flight Day')
% ylabel('Accuracy (m)')
% xlabel('Flight Test and Wind Speed')
% legend('BASE','','Airspeed','','Dual GPS','')
% 
% xticks([1 2 3 4 5 6 7])
% xticklabels({'1st(7m/s)','2nd(6m/s)','3rd (1m/s)','4th (3m/s)','5th (3m/s)','6th (1m/s)'})


% figure
% 
% plot(ARSPD(:,5),ARSPD(:,2),'b-','LineWidth',2)
% hold on
% plot(ARSPD(:,5),ARSPD(:,2),'bo','MarkerSize',7,'MarkerFaceColor','b')
% plot(BASE(:,5),BASE(:,2),'r--','LineWidth',2)
% plot(BASE(:,5),BASE(:,2),'ro','MarkerSize',7,'MarkerFaceColor','r')
% plot(DUAL(:,5),DUAL(:,2),'g-.','LineWidth',2)
% plot(DUAL(:,5),DUAL(:,2),'go','MarkerSize',7,'MarkerFaceColor','g')
% title('Waypoint Repeatability on Flight Day')
% ylabel('Repeatability (m)')
% xlabel('Flight Test and Wind Speed')
% legend('Airspeed','','Base','','Dual GPS','')
% 
% 
% xticks([1 2 3 4 5 6 7])
% xticklabels({'1st(7m/s)','2nd(6m/s)','3rd (1m/s)','4th (3m/s)','5th (3m/s)','6th (1m/s)'})

% figure
% 
plot(ARSPD(:,5),ARSPD(:,3),'b-','LineWidth',2)
hold on
plot(ARSPD(:,5),ARSPD(:,3),'bo','MarkerSize',7,'MarkerFaceColor','b')
plot(BASE(:,5),BASE(:,3),'r--','LineWidth',2)
plot(BASE(:,5),BASE(:,3),'ro','MarkerSize',7,'MarkerFaceColor','r')
plot(DUAL(:,5),DUAL(:,3),'g-.','LineWidth',2)
plot(DUAL(:,5),DUAL(:,3),'go','MarkerSize',7,'MarkerFaceColor','g')
title('Path Accuracy on Flight Day')
ylabel('Path Accuracy (m)')
xlabel('Flight Test and Wind Speed')
legend('Airspeed','','Base','','Dual GPS','')
xticks([1 2 3 4 5 6 7])
xticklabels({'1st(7m/s)','2nd(6m/s)','3rd (1m/s)','4th (3m/s)','5th (3m/s)','6th (1m/s)'})
