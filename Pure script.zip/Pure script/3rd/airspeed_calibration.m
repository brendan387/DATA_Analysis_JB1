clf

ST = 3000
ED = 4500

for row = ST:ED
    GPS_ASP(row-ST+1,2) = GPS(row,9)*(0.9999995+(rand/1000000));
    GPS_ASP(row-ST+1,3) = GPS(row,10)*(0.9999995+(rand/1000000));
    
end

GPS_ASP(:,1)=(GPS(ST:ED,2)-GPS(ST,2))/(1e6*22/15);
GPS_ASP(:,2)= smooth(GPS_ASP(:,2));
GPS_ASP(:,3)= smooth(GPS_ASP(:,3));

geoplot(GPS_ASP(:,2),GPS_ASP(:,3),'r')

GS = GPS(ST:ED,12)-4.67;
ASP = smooth(ARSP(ST:ED,4)-6.5453);

avgGS = mean(GS)
avgASP = mean(ASP)

figure
plot(GPS_ASP(:,1),GS,'r')
hold on
plot(GPS_ASP(:,1),ASP,'b','LineWidth',0.1)

yline(avgGS,'--r','LineWidth',3);
yline(avgASP,'--k','LineWidth',3);

legend('GroundSpeed','Airspeed','Average Ground Speed','Average AirSpeed','FontSize',12,'FontWeight','bold')
axis tight

[t] = title ('Air and Ground speed for presure sensor calibration')
t.FontSize = 20;

set(gca,'FontSize',12)

xlabel('Time (s)','FontSize',16,'FontWeight','bold') 
ylabel('Speed (m/s)','FontSize',16,'FontWeight','bold') 




