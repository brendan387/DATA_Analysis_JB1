clf
geoplot(WAY(:,1),WAY(:,2),'black -o')
hold on

load('1-3 loop.mat')

St = 100;
Ed = 3400;

GPS12= [GPS(St:Ed,8),GPS(St:Ed,9),GPS(St:Ed,2)];
GPS12_Alt=[];

geoplot(GPS12(:,1),GPS12(:,2),'r')

for row = 1:length(GPS12)

    % range finder Altitude data
    [~,AHR2Index] = min(abs(AHR2(:,2)-GPS12(row,3)));
    AHR2_time = AHR2(AHR2Index,2);
    
    GPS12_Alt = [GPS12_Alt;AHR2(AHR2Index,6),AHR2(AHR2Index,2)];
    
end


clearvars -except WAY GPS1_Alt GPS2_Alt GPS3_Alt GPS4_Alt GPS5_Alt GPS6_Alt GPS7_Alt GPS8_Alt GPS9_Alt GPS10_Alt GPS11_Alt GPS12_Alt GPS1 GPS2 GPS3 GPS4 GPS5 GPS6 GPS7 GPS8 GPS9 GPS10 GPS11 GPS12

