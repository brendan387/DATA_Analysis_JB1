GPS_Lat= GPS7(:,1); 
GPS_Lon= GPS7(:,2);
Error_Dist7=[];

geoplot(GPS_Lat,GPS_Lon,'black -')
hold on
geoplot(WAY(:,1),WAY(:,2),'black -o')

figure

GPS_Lat_Lon = [GPS_Lat,GPS_Lon];
GPS_Size = length(GPS_Lat_Lon);

GPS_Time = 0;%GPS(:,2);

WAY_Lat= WAY(:,1);
WAY_Lon= WAY(:,2);

% number of points to add between intial waypoint locations
WAY_Size = length(WAY);

numberofpoints = GPS_Size;

Improved_WAY_LAT= [];
Improved_WAY_LON= [];
Improved_WAY = [];
t=0;

for n=1:WAY_Size-1
    %location to add new points in matrix
    a = (n-1)*numberofpoints+1;
    b = t+numberofpoints;
    
    %%%% Temporay Latitude values
    %Fills in line of waypoints for Latitude
    LAT = linspace(WAY(n,1), WAY(n+1,1), numberofpoints); %includes start, end point and number of points to add
    Improved_WAY_LAT(a:b,1) = LAT';

    %%%% Temporay Longitudinal values
    %Fills in line of waypoints for long
    LON = (linspace(WAY(n,2), WAY(n+1,2), numberofpoints)); %includes start, end point and number of points to add
    Improved_WAY_LON(a:b,1) = LON';
    
    Improved_WAY = [Improved_WAY_LAT,Improved_WAY_LON];
    
    
    %track of current location in array
    t= t+ numberofpoints;
end

geoplot(WAY(:,1),WAY(:,2),'black --')
hold on
geoplot(WAY(:,1),WAY(:,2),'black o','Markersize',12)

%Rearraange waypoints to match  
k = dsearchn(Improved_WAY,GPS_Lat_Lon(1,:));
Improved_WAY = [Improved_WAY(k:end,:);Improved_WAY(1:k-1,:)];


errorCords = [];
errorPath = [];
% average radius of the Earth
radius=6371000;


Error_Dist_time = [];
near_Row = 0;

for Row = 1:length(GPS_Lat_Lon)
    
    Improved_WAY(1:near_Row,:)=[];
    % make sure values do not excced range of possible values
    range = near_Row+50;
    if range >= length(Improved_WAY)
        range = size(Improved_WAY);
    end
    
    
    
    near_Row = dsearchn(Improved_WAY(1:range,:),GPS_Lat_Lon(Row,:));
    
    errorCords = [GPS_Lat_Lon(Row,:);Improved_WAY(near_Row,:)];
    geoplot(errorCords(:,1),errorCords(:,2)) 
   
    
    
    
    %%% determine distance between 2 coordinates %%%
    lat1=errorCords(1,1)*pi/180;
    lat2=errorCords(2,1)*pi/180;
    lon1=errorCords(1,2)*pi/180;
    lon2=errorCords(2,2)*pi/180;
   
    deltaLat=lat2-lat1;
    deltaLon=lon2-lon1;
        
    a=sin((deltaLat)/2)^2 + cos(lat1)*cos(lat2) * sin(deltaLon/2)^2;
    c=2*atan2(sqrt(a),sqrt(1-a));
    
%   Error_Dist_time =[Error_Dist_time;GPS_Time(Row,1)];
    Error_Dist7 =[Error_Dist7;radius*c];%Haversine model based Error distance
    
    
    
end


geoplot(GPS_Lat,GPS_Lon,'blue')