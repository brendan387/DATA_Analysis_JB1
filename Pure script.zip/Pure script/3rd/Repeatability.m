%%% Repeatability %%%

load('All loops + Alt.mat')

%Modify to change loop
TEMP_GPS = GPS7(:,1:2);
TEMP_GPS_Alt = GPS7_Alt(:,1);
XYZ7 = [];
AP_RP7 = [];


for n = 1:length(WAY)
    WAY_Alt(n,1) = mean(TEMP_GPS_Alt)*(1+(rand(1)/101));
end

%geoplot(WAY(:,1),WAY(:,2),'black --')
hold on

%geoplot(TEMP_GPS(:,1),TEMP_GPS(:,2),'blue -')

Xt_WAY_COR=[];
WAY_NUM= [];
DEV= [];
radius=6371000;




% find distances between actual and real coordinates
for St = 1:length(WAY)
    % k is index cloest to waypoint
    k = dsearchn(TEMP_GPS,WAY(St,:));

    Xt_temp = [TEMP_GPS(k,1:2);WAY(St,:)];
    
    %geoplot(Xt_temp(:,1),Xt_temp(:,2),'red -')
    
    Xt_WAY_COR = [Xt_WAY_COR; Xt_temp];
    
    WAY_NUM = [WAY_NUM;St,WAY(St,:),k,TEMP_GPS(k,1:2)];
    
    %% convert Caclate bearing from waypoint to path point
    lat1 = WAY(St,1);
    lon1 = WAY(St,2);

    lat2 = TEMP_GPS(k,1);
    lon2 = TEMP_GPS(k,2);
    
    bearing_dev(St,:)= -atan2(sin(lon2-lon1)*cos(lat2),(cos(lat1)*sin(lat2)-sin(lat1)*cos(lat2))*cos(lon2-lon1));

    bearing_dev(St,:) = mod(rad2deg(bearing_dev(St,:))+360,360);
    
    %% convert Caclate Xt from waypoint to path point
    lat1 = WAY(St,1)*pi/180;
    lon1 = WAY(St,2)*pi/180;

    lat2 = TEMP_GPS(k,1)*pi/180;
    lon2 = TEMP_GPS(k,2)*pi/180;
   
    deltaLat=lat2-lat1;
    deltaLon=lon2-lon1;
        
    a=sin((deltaLat)/2)^2 + cos(lat1)*cos(lat2) * sin(deltaLon/2)^2;
    c=2*atan2(sqrt(a),sqrt(1-a));
    
    DEV =[DEV;radius*c];%Haversine model based deviation distance
    
    
    %% convert Xt to xy coordinates
    hyp = radius*c;
    bearing = bearing_dev(St,:);

    if  (bearing >= 0) && (bearing <= 90)
        angle = bearing;
        x_factor = 1;
        y_factor = 1;

    elseif (bearing >= 90) && (bearing <= 180)
        angle = bearing-90;
        x_factor = 1;
        y_factor = -1;
    elseif (bearing >= 180) && (bearing <= 270)
        angle = bearing-180;
        x_factor = -1;
        y_factor = -1;

    else
        angle = bearing-270;
        x_factor = -1;
        y_factor = 1;
    
    end
    x = hyp*cos(deg2rad(angle))*x_factor;
    y = hyp*sin(deg2rad(angle))*y_factor;
    
    %% Caclate z against 
    %z distance
    z = TEMP_GPS_Alt(k,1)- WAY_Alt(St,:);
    
    XYZ7= [XYZ7;x,y,z];
end

%% Repeatability based on ISO method 9283

x_bar = mean(XYZ7(:,1));
y_bar = mean(XYZ7(:,2));
z_bar = mean(XYZ7(:,3));

DEV_3_xs = sqrt(((XYZ7(:,1)-x_bar).^2)+((XYZ7(:,2)-y_bar).^2)+((XYZ7(:,3)-z_bar).^2));

DEV_3_xs_bar = mean(DEV_3_xs);

STD_top =  sum((DEV_3_xs-DEV_3_xs_bar).^2);

STD = sqrt(STD_top/length(XYZ7));

AP = sqrt((x_bar^2)+(y_bar^2)+(z_bar^2));

% Repeatability
RP = DEV_3_xs_bar + 3*STD;

AP_RP7= [AP,RP,STD,DEV_3_xs_bar]

scatter3(XYZ7(:,1),XYZ7(:,2),XYZ7(:,3),'*')
view(-30,10)
hold on
scatter3(0,0,0,'black*')

%%clean up workspace
clearvars -except bearing_dev WAY WAY_Alt XYZ1 XYZ2 XYZ3 XYZ4 XYZ5 XYZ6 XYZ7 XYZ8 XYZ9 XYZ10 XYZ11 XYZ12 AP_RP1 AP_RP2 AP_RP3 AP_RP4 AP_RP5 AP_RP6 AP_RP7 AP_RP8 AP_RP9 AP_RP10 AP_RP11 AP_RP12