GPS_Time = GPS_loop_2(:,3);

[time,botAHR2Index] = min(abs(AHR2(:,2)-GPS_Time(1,:)));
[time,topAHR2Index] = min(abs(AHR2(:,2)-GPS_Time(end,:)));

AHR2 = AHR2(botAHR2Index:topAHR2Index,:);


[time,botATTIndex] = min(abs(ATT(:,2)-GPS_Time(1,:)));
[time,topATTIndex] = min(abs(ATT(:,2)-GPS_Time(end,:)));

ATT = ATT(botATTIndex:topATTIndex,:);

[~,botTECSIndex] = min(abs(TECS(:,2)-GPS_Time(1,:)));
[~,topTECSIndex] = min(abs(TECS(:,2)-GPS_Time(end,:)));

TECS = TECS(botTECSIndex:topTECSIndex,:);


[~,botNTUNIndex] = min(abs(NTUN(:,2)-GPS_Time(1,:)));
[~,topNTUNIndex] = min(abs(NTUN(:,2)-GPS_Time(end,:)));

NTUN = NTUN(botNTUNIndex:topNTUNIndex,:);

[~,botCTUNIndex] = min(abs(CTUN(:,2)-GPS_Time(1,:)));
[~,topCTUNIndex] = min(abs(CTUN(:,2)-GPS_Time(end,:)));

CTUN = CTUN(botCTUNIndex:topCTUNIndex,:);

[~,botBAROIndex] = min(abs(BARO(:,2)-GPS_Time(1,:)));
[~,topBAROIndex] = min(abs(BARO(:,2)-GPS_Time(end,:)));

BARO = BARO(botBAROIndex:topBAROIndex,:);





clearvars -except AHR2 Error_Dist GPS_loop_2 GPS_loop_1 GPS WAY TECS BARO ATT NTUN CTUN





