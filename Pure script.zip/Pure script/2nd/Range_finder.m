% figure
% plot(RFND(25735:26430,4))

Start_loop = 2574
End_loop = 2644
radius=6371000;

Altitude = GPS(2574:2644,10)-7;

Cumulative_ground_distance=0;
Ground_distance=[];

for Row = 2574:2644
    %%% determine distance between 2 coordinates %%%
    lat1=GPS(Row,8)*pi/180;
    lat2=GPS(Row+1,8)*pi/180;
    
    lon1=GPS(Row,9)*pi/180;
    lon2=GPS(Row+1,9)*pi/180;
   
    deltaLat=lat2-lat1;
    deltaLon=lon2-lon1;
    
    a=sin((deltaLat)/2)^2 + cos(lat1)*cos(lat2) * sin(deltaLon/2)^2;
    c=2*atan2(sqrt(a),sqrt(1-a));
    
    Cumulative_ground_distance = Cumulative_ground_distance+radius*c;
    
    Ground_distance =[Ground_distance;Cumulative_ground_distance];%Haversine model based Error distance
    
end



    

figure
plot(Ground_distance,Altitude)

title('Range finder calculated Altitude in landing')
xlabel('Ground Distance(m)')
ylabel('Altitude above Ground Level(m)')
