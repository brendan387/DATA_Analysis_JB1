x = 1940;
loop = 485; %485

GPS_Lat= GPS(x:x+loop,8);  %1500 max
GPS_Lon= GPS(x:x+loop,9); %1500 max

GPS_Lat_Lon = [GPS_Lat,GPS_Lon];
GPS_Size = length(GPS_Lat_Lon)

WAY_Lat= WAY(:,1);
WAY_Lon= WAY(:,2);

% number of points to add between intial waypoint locations
WAY_Size = length(WAY);

numberofpoints = round((GPS_Size/WAY_Size)*1.2);


Improved_WAY_LAT= [];
Improved_WAY_LON= [];
t=0;

for n= 1:WAY_Size-1
    %location to add new points in matrix
    a = (n-1)*numberofpoints+1;
    b = t+numberofpoints;
    
    
    %%%% Temporay Latitude values
    %Fills in line of waypoints for lat
    LAT = linspace(WAY(n,1), WAY(n+1,1), numberofpoints); %includes start, end point and number of points to add
    Improved_WAY_LAT(a:b,1) = LAT';
      
    
    %%%% Temporay Longitudinal values
    %Fills in line of waypoints for lat
    LON = (linspace(WAY(n,2), WAY(n+1,2), numberofpoints)); %includes start, end point and number of points to add
    Improved_WAY_LON(a:b,1) = LON';
    
    %track of current location in array
    t= t+ numberofpoints;
end




Improved_WAY = [Improved_WAY_LAT,Improved_WAY_LON];

WAY_Size = length(Improved_WAY)

Course_Error = 0;

k = dsearchn(Improved_WAY,GPS_Lat_Lon(1,:))

Improved_WAY = [Improved_WAY(k:end,:);Improved_WAY(1:k-1,:)];

equ_factor = 6;
v=1;
WAY_Size = length(Improved_WAY)

for s = 1:equ_factor:length(Improved_WAY)-k-v
    Improved_WAY(s,:) = [];
    v=v+1;
end

geoplot(Improved_WAY(:,1),Improved_WAY(:,2),'g-*')
hold on

% average radius of the Earth
radius=6371/1000;

WAY_Size = length(Improved_WAY)
GPS_Size = length(GPS_Lat_Lon)
Error_Dist=[0];
ErrorPath =[0];

for row = 1:length(GPS_Lat_Lon)
    
    %visualise error distance between waypoints and actual flight path
    ErrorPath = [Improved_WAY(row,:);GPS_Lat_Lon(row,:)];
    geoplot(ErrorPath(:,1),ErrorPath(:,2))
    
%     lat1=Improved_WAY(row,1)*pi/180;
%     lat2=Improved_WAY(row,2)*pi/180;
%     lon1=GPS_Lat_Lon(row,1)*pi/180;
%     lon2=GPS_Lat_Lon(row,2)*pi/180;
%     
%     deltaLat=lat2-lat1;
%     deltaLon=lon2-lon1;
%     a=sin((deltaLat)/2)^2 + cos(lat1)*cos(lat2) * sin(deltaLon/2)^2;
%     c=2*atan2(sqrt(a),sqrt(1-a));
%     
%     Error_Dist =[Error_Dist;radius*c];  %Haversine model based Error distance
    
    
end

geoplot(GPS_Lat,GPS_Lon)
hold off

% figure
% plot(Error_Dist)
% 
% minimum = min(Error_Dist)
% maximum = max(Error_Dist)









