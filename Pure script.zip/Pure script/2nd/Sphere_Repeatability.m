clf
%plot repeatability sphere
[x,y,z] = sphere;

scatter3(XYZ2(:,1),XYZ2(:,2),XYZ2(:,3),'s red')
view(-45,20)
hold on
scatter3(0,0,0,'black+')

x= (x*AP_RP2(:,2))+AP_RP2(:,5);
y= (y*AP_RP2(:,2))+AP_RP2(:,6);
z= (z*AP_RP2(:,2))+AP_RP2(:,7);
surf(x,y,z,'FaceColor','k','FaceAlpha',.1,'EdgeAlpha',.3);

offset = [AP_RP2(:,5),AP_RP2(:,6),AP_RP2(:,7);0,0,0];
plot3(offset(:,1),offset(:,2),offset(:,3),'black--')

lgd = legend({'Data',['Barry Center / Average' newline 'Deviation Point'],'Sphere of Precision'});
title('Sphere of Repeatability Loop 2')

xlabel('Deviation in x (m)')
ylabel('Deviation in y (m)')
zlabel('Deviation in z(m)')



%scatter3(XYZ2(:,1),XYZ2(:,2),XYZ2(:,3),'+')