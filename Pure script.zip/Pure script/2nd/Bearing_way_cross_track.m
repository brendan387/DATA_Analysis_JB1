%%%cross track error against bearing to waypoint%%%
geoplot(WAY(:,1),WAY(:,2),'black -o')
hold on

%Rearraange waypoints to match  
k = dsearchn(GPS_loop_2(:,1:2),WAY(1,:));
SEG_temp = [GPS_loop_2(k:length(GPS_loop_2),1:2);GPS_loop_2(1:k-1,1:2)];
SEG = [GPS_loop_2(k:length(GPS_loop_2),1:2);GPS_loop_2(1:k-1,1:2)];


X_err = [Error_Dist(k:length(Error_Dist),2);Error_Dist(1:k-1,2)];


%splits route to avoid later values mistaken for earlier.
range_factor = round(length(SEG_temp)/length(WAY));
t=0;
near_Row=0;
WAY_seg =[];
WAY_test=[];


for Row = 1:length(WAY)
    
    range = near_Row+range_factor;
    if range >= length(SEG_temp)
        range = length(SEG_temp);
    end
    t = t+near_Row;
    
    near_Row = dsearchn(SEG_temp(1:range,:),WAY(Row,:));
    WAY_seg = [WAY_seg;near_Row+t,Row];
       
    if near_Row >= length(SEG_temp)
        near_Row = length(SEG_temp)-1;
    end
    
    SEG_temp(1:near_Row,:) = [];
    
    
    WAY_test=[SEG(near_Row+t,:);WAY(Row,:)];
    geoplot(WAY_test(:,1),WAY_test(:,2),'red -')
    hold on
end

%NTUN cross track error used to evaluate accuracy
%determine bearing of segment between 

for row=1:length(WAY)-1
    lat1 = WAY(row,1);
    lon1 = WAY(row,2);

    lat2 = WAY(row+1,1);
    lon2 = WAY(row+1,2);

    WAYbearing(row,:)= -atan2(sin(lon2-lon1)*cos(lat2),(cos(lat1)*sin(lat2)-sin(lat1)*cos(lat2))*cos(lon2-lon1));

    WAYbearing(row,:) = mod(rad2deg(WAYbearing(row,:))+360,360);
end

%loop takes average of the error distance between

avg_X =[];

for row=1:length(WAY_seg)-1

    avg_X =[avg_X;X_err(WAY_seg(row,1)),X_err(WAY_seg(row+1,1)),mean(X_err(WAY_seg(row:row+1,1)))];


end

X_bearing = [WAYbearing,avg_X(:,3)];

sorted_X_bearing = X_bearing;%sortrows(X_bearing,2);

deg_off_wind = []

for row = 1:length(sorted_X_bearing)
    
    
    temp_deg = sorted_X_bearing(row,1) - 45;
    frac_bear=temp_deg/180
    
    
    if frac_bear > 1
        frac_bear =(1-(frac_bear - 1))*-1;
    end
    
    temp_deg = abs(frac_bear*180)
    
    deg_off_wind= [deg_off_wind;temp_deg];

end

sorted_X_bearing(:,1)=deg_off_wind


figure
semilogy(deg_off_wind,sorted_X_bearing(:,2),'x')
title('Crosstrack error against Crosstrack Bearing')
xlabel('Crosstrack Bearing ')
ylabel('Crosstrack Error Distance(m)')


