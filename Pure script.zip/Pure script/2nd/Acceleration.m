x = 2000; %prime,2000 %Deprocated,1940
loop = 485; %prime,485 %Deprocated,477
% find closest time value between yaw and time of loop
loop_GPS=[GPS(x:x+loop,:)];
loop_Lat_lon=[GPS(x:x+loop,8),GPS(x:x+loop,9)];

%find region matching loop in acceleration
[~,botLoopIndex] = min(abs(TECS(:,2)-loop_GPS(1,2)));
[~,topLoopIndex] = min(abs(TECS(:,2)-loop_GPS(length(loop_GPS),2)));


acc = [TECS(botLoopIndex:topLoopIndex,2),TECS(botLoopIndex:topLoopIndex,9)];
figure
plot((acc(:,1)-loop_GPS(1,2))/1e6,acc(:,2),'black')

title('Acceleration vs Time')
xlabel('Time(s)')
ylabel('Acceleration of the Aircraft (ms^2)')
axis tight
hold off




%Rearraange waypoints to match  
k = dsearchn(loop_Lat_lon,WAY(1,:));

SEG_temp = [loop_Lat_lon(k:end,:);loop_Lat_lon(1:k-1,:)];
SEG = [loop_Lat_lon(k:end,:);loop_Lat_lon(1:k-1,:)];
X_err = [Error_Dist(k:end,:);Error_Dist(1:k-1,:)];
%find location of start point and rearrange the data matching loop for acceleration
[timeStart,Index] = min(abs(acc(:,1)-loop_GPS(k,2)));

acc_mod = [acc(Index:end,:);acc(1:Index-1,:)];



%splits route to avoid later values mistaken for earlier.
range_factor = round(length(SEG_temp)/length(WAY));
t=0;
near_Row=0;
WAY_seg =[];
WAY_test=[];


for Row = 1:length(WAY)
    
    range = near_Row+range_factor;
    if range >= length(SEG_temp)
        range = length(SEG_temp);
    end
    t = t+near_Row;
    
    near_Row = dsearchn(SEG_temp(1:range,:),WAY(Row,:));
    
    WAY_seg = [WAY_seg;near_Row+t,Row,];
       
    if near_Row >= length(SEG_temp)
        near_Row = length(SEG_temp)-1;
    end
    
    SEG_temp(1:near_Row,:) = [];
end

%NTUN cross track error used to evaluate accuracy
%determine bearing of segment between 

for row=1:length(WAY)-1
    lat1 = WAY(row,1);
    lon1 = WAY(row,2);

    lat2 = WAY(row+1,1);
    lon2 = WAY(row+1,2);

    WAYbearing(row,:)= -atan2(sin(lon2-lon1)*cos(lat2),(cos(lat1)*sin(lat2)-sin(lat1)*cos(lat2))*cos(lon2-lon1));

    WAYbearing(row,:) = mod(rad2deg(WAYbearing(row,:))+360,360);
end

%loop takes average of the error distance between

avg_acc =[];

%find nearest row in TEC when corresponding to segment
for row=1:1%length(WAY_seg)
    
    [~,Index] = min(abs(acc(:,1)-WAY_seg(row,1)));
    
    acc_seg(row,:) =[Index];  
end
% 
% %find nearest row in TEC when corresponding to segment
% 
% acc_rearrange = [acc(acc_seg(1,:):end,:);acc(1:acc_seg(row,:)-1,:)];
% 
% for row=1:length(acc_seg)-1
%     
%    avg_acc_seg(row,:) =[acc(acc_seg(row,:),1),acc(acc_seg(row+1,:),1),mean(acc(acc_seg(row,:):acc_seg(row+1,:),1))];    
% end
% 
% 
% 
% figure
% 
% bearing_acc = [WAYbearing,avg_acc_seg(:,3)];
% 
% sorted_X_bearing =  sortrows(X_bearing,2);
% 
% 
% plot(smooth(sorted_X_bearing(:,1)),smooth(sorted_X_bearing(:,2)))
% title('Crosstrack error against Crosstrack Bearing')
% xlabel('Crosstrack Bearing ')
% ylabel('Acceleration')

