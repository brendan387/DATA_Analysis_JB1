x=2614 %3365
loop = 453 %678

GPS_Time= GPS(x:x+loop,9);

GPS_Lat= GPS(x:x+loop,9);  %1500 max
GPS_Lon= GPS(x:x+loop,10); %1500 max

GPS_Lat_Lon = [GPS_Lat,GPS_Lon];
GPS_Size = length(GPS_Lat_Lon);

WAY_Lat= WAY(:,1);
WAY_Lon= WAY(:,2);

% number of points to add between intial waypoint locations
WAY_Size = length(WAY);

numberofpoints = GPS_Size/1.1;

Improved_WAY_LAT= [];
Improved_WAY_LON= [];
Improved_WAY = [];
t=0;

geoplot(GPS_Lat,GPS_Lon,'blue')

for n=1:WAY_Size-1
    %location to add new points in matrix
    a = (n-1)*numberofpoints+1;
    b = t+numberofpoints;
    
    %%%% Temporay Latitude values
    %Fills in line of waypoints for Latitude
    LAT = linspace(WAY(n,1), WAY(n+1,1), numberofpoints); %includes start, end point and number of points to add
    Improved_WAY_LAT(a:b,1) = LAT';

    %%%% Temporay Longitudinal values
    %Fills in line of waypoints for long
    LON = (linspace(WAY(n,2), WAY(n+1,2), numberofpoints)); %includes start, end point and number of points to add
    Improved_WAY_LON(a:b,1) = LON';
    
    Improved_WAY = [Improved_WAY_LAT,Improved_WAY_LON];
    
    
    %track of current location in array
    t= t+ numberofpoints;
end

geoplot(WAY(:,1),WAY(:,2),'black --')
hold on

%Rearraange waypoints to match  
k = dsearchn(Improved_WAY,GPS_Lat_Lon(1,:))
Improved_WAY = [Improved_WAY(k:end,:);Improved_WAY(1:k-1,:)];


errorCords = [];
errorPath = [];
% average radius of the Earth
radius=6371000;

Error_Dist=[];
Error_max = [];
near_Row = 0;

for Row = 1:length(GPS_Lat_Lon)
    
    Improved_WAY(1:near_Row,:)=[];
    % make sure values do not excced range of possible values
    range = near_Row+20;
    if range >= length(Improved_WAY)
        range = length(Improved_WAY);
    end
       
    
    near_Row = dsearchn(Improved_WAY(1:range,:),GPS_Lat_Lon(Row,:));
    
    length(Improved_WAY)
    length (GPS_Lat_Lon)
    
    
    
    errorCords = [GPS_Lat_Lon(Row,:);Improved_WAY(near_Row,:)];
    geoplot(errorCords(:,1),errorCords(:,2)) 
    
    
    %%% determine distance between 2 coordinates %%%
    lat1=errorCords(1,1)*pi/180;
    lat2=errorCords(2,1)*pi/180;
    lon1=errorCords(1,2)*pi/180;
    lon2=errorCords(2,2)*pi/180;
   
    deltaLat=lat2-lat1;
    deltaLon=lon2-lon1;
        
    a=sin((deltaLat)/2)^2 + cos(lat1)*cos(lat2) * sin(deltaLon/2)^2;
    c=2*atan2(sqrt(a),sqrt(1-a));
    
    Error_Dist =[Error_Dist;radius*c];%Haversine model based Error distance
        
end

geoplot(GPS_Lat,GPS_Lon,'blue')

% figure
% plot(GPS(x:x+loop,2),Error_Dist)

% minimum = min(Error_Dist)
% maximum = max(Error_Dist)
% AVG = mean(Error_Dist)
% Mod = mode(Error_Dist)
% standard_Deviation=std(Error_Dist)

%boxplot(Error_Dist)






