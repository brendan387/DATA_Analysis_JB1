WAY_Cor = [];

WAY_Cor(:,1)= WAY(:,1);
WAY_Cor(:,2)= WAY(:,2);

Wind_dir = 45;

Wind_Corr_dir = Wind_dir+180;

if Wind_Corr_dir>360
    Wind_Corr_dir = Wind_Corr_dir - 360;
end

for Active_Point=1:length(WAY(:,1))
    
    lat1 = WAY(Active_Point,1);
    lon1 = WAY(Active_Point,2);
    
    if Active_Point < length(WAY(:,1))
        lat2 = WAY(Active_Point+1,1);
    	lon2 = WAY(Active_Point+1,2);
        
        WAY_Cor(Active_Point,3)= -atan2(sin(lon2-lon1)*cos(lat2),(cos(lat1)*sin(lat2)-sin(lat1)*cos(lat2))*cos(lon2-lon1));
        
        WAY_Cor(Active_Point,3) = mod(rad2deg(WAY_Cor(Active_Point,3))+360,360);
    end
    
    if WAY_Cor(Active_Point,3)-40 < Wind_dir && WAY_Cor(Active_Point,3)+40 > Wind_dir
              
        lat = WAY(Active_Point,1); 
        long = WAY(Active_Point,2);
        %Number of meters to calculate coords for north/south/east/west

        equator_circumference = 6371000; %meters
        polar_circumference = 6356800; %meters

        m_per_deg_long = 360 / polar_circumference;

        rad_lat = (lat * pi / 180); %convert to radians, cosine takes a radian argument and not a degree argument
        m_per_deg_lat = 360 / (cos(rad_lat) * equator_circumference);

        
        % correction distance in meter and how far they will move in
        % longitude and latitude
        dist_corr = 1.1; %distance in meters that the 
        
        
        deg_diff_long = dist_corr*sin(Wind_Corr_dir) * m_per_deg_long*dist_corr;  %Number of degrees Latitude as you move north/south along the line of Longitude
        deg_diff_lat = dist_corr*cos(Wind_Corr_dir) * m_per_deg_lat*dist_corr; %Number of degrees Longitude as you move east/west along the line of Latitude
        
        if WAY(Active_Point,1) > 54.4520586
            Cor_factor = 1;
        elseif WAY(Active_Point,1) < 54.4520586
            Cor_factor = -1;
        end
        %Latitude move
        WAY_Cor(Active_Point,1) = lat + deg_diff_long*Cor_factor;
        %Longitude
        WAY_Cor(Active_Point,2)= long + deg_diff_lat*Cor_factor;
        
        WAY_Cor(length(WAY_Cor),1)=WAY_Cor(1,1);
        WAY_Cor(length(WAY_Cor),2)=WAY_Cor(1,2);
    end
end

geoplot(WAY(:,1),WAY(:,2),'black --')
hold on
geoplot(WAY_Cor(:,1),WAY_Cor(:,2),'r--')