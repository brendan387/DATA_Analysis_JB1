clf
geoplot(WAY(:,1),WAY(:,2),'black -o')
hold on

load('2nd flight Test')

St = 2000;
Ed = 2485;

% St = 100;
% Ed = 4900;

GPS1= [GPS(St:Ed,8),GPS(St:Ed,9),GPS(St:Ed,2)];
GPS1_Alt=[];

geoplot(GPS1(:,1),GPS1(:,2),'r')

for row = 1:length(GPS1)

    % range finder Altitude data
    [~,AHR2Index] = min(abs(AHR2(:,2)-GPS1(row,3)));
    AHR2_time = AHR2(AHR2Index,2);
    
    GPS1_Alt = [GPS1_Alt;AHR2(AHR2Index,6),AHR2(AHR2Index,2)];
    
end


clearvars -except WAY GPS1_Alt GPS2_Alt GPS1 GPS2
