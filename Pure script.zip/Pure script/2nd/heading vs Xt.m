sorted_X_bearing = ATT(1:end-1,8);

deg_off_wind = []

for row = 1:length(sorted_X_bearing)
    
    
    temp_deg = sorted_X_bearing(row,:) - 45;
    frac_bear=temp_deg/180;
    
    
    if frac_bear > 1
        frac_bear =((frac_bear - 1))*-1;
    end
    
    temp_deg = abs(frac_bear*180);
    
    deg_off_wind= [deg_off_wind;temp_deg];

end

plot(deg_off_wind,abs(NTUN(:,7)),'.')




% ratio=round(length(NTUN)/length(Error_Dist))
% 
% int_Error_Dist = [];
% 
% 
% for row=1:length(Error_Dist)-1
%     
%     int_Error_Dist = [int_Error_Dist;(linspace(Error_Dist(row,2),Error_Dist(row+1,2),ratio))'];
% 
% end


%test = sortrows(test,2);


% semilogy(deg_off_wind,abs(NTUN(:,7)),'b.')
% 
% figure
% 



% plot((NTUN(:,2)-NTUN(1,2))/1e6,abs(NTUN(:,7)),'r')
% 
% hold on
% 
% plot((NTUN(2:length(NTUN)-1,2)-NTUN(2,2))/1e6,int_Error_Dist,'b')



title('Crosstrack error against Crosstrack Bearing')
xlabel('Crosstrack Bearing ')
ylabel('Crosstrack Error Distance(m)')