x = 2000; %prime,2000 %Deprocated,1940
loop = 485; %prime,485 %Deprocated,477
% find closest time value between yaw and time of loop
[timeStart,botLoopIndex] = min(abs(ATT(:,2)-GPS(x,2)));
[timeEnd,topLoopIndex] = min(abs(ATT(:,2)-GPS(x+loop,2)));

Bearing = ATT(botLoopIndex:topLoopIndex,8)

plot(Bearing)
