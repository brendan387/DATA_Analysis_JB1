

plot(test_way(:,1),test_way(:,2),'red.-','MarkerSize',20)
hold on
plot(test_way(:,1),test_way(:,3),'blue.-','MarkerSize',20)

axis([0 7 0 30] )
title('Crosstrack error against Waypoint Number')
xlabel('Waypoint Number')
ylabel('Waypoint Deviation(m)')
hold off

figure
plot(test_SEG(:,1),test_SEG(:,2),'red.-','MarkerSize',20)
hold on
plot(test_SEG(:,1),test_SEG(:,3),'blue.-','MarkerSize',20)

axis([0 65 0 35] )
title('Crosstrack error against Waypoint Number')
xlabel('Waypoint Number')
ylabel('Average Cross-track Deviation(m)')
hold off