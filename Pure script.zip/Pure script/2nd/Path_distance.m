%Standard Deviation each segment

% find nearest point
TEMP_GPS = GPS_loop_2(:,1:2);
TEMP_Time = GPS_loop_2(:,3);

Path_Time = (TEMP_Time(length(TEMP_Time),:)-TEMP_Time(1,:))/1e6;

% rearrange data so waypoint 1 is stat of gps data
k_arr = dsearchn(TEMP_GPS,WAY_MIN(1,:));
TEMP_GPS = [TEMP_GPS(k_arr:end,:);TEMP_GPS(1:k_arr,:)];
%TEMP_Time = [TEMP_Time(k_arr:end,:);TEMP_Time(1:k_arr,:)];


cuml_loop_dist = 0;
cuml_PATH_Time = 0;
PATH_Time = [];
loop_dist = [];
radius=6371000;

for St = 1:length(TEMP_GPS)-1
    
    %%% determine distance between 2 coordinates %%%
    lat1=TEMP_GPS(St,1)*pi/180;
    lat2=TEMP_GPS(St+1,1)*pi/180;
    lon1=TEMP_GPS(St,2)*pi/180;
    lon2=TEMP_GPS(St+1,2)*pi/180;
   
    deltaLat=lat2-lat1;
    deltaLon=lon2-lon1;
        
    a=sin((deltaLat)/2)^2 + cos(lat1)*cos(lat2) * sin(deltaLon/2)^2;
    c=2*atan2(sqrt(a),sqrt(1-a));
    
    cuml_loop_dist = cuml_loop_dist+radius*c;
    
    %Current distance between point , Cululative distance of the route
    loop_dist(St,:) =[radius*c,cuml_loop_dist,cuml_loop_dist];
end


