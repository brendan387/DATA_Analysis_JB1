x = 2500;
loop= 200;

% Barometer altitude data for time
[timeStart,BAROBotLoopIndex] = min(abs(BARO(:,2)-GPS(x,2)));
[timeEnd,BAROTopLoopIndex] = min(abs(BARO(:,2)-GPS(x+loop,2)));

% Terrain altitude data for time
[timeStart,TERRBotLoopIndex] = min(abs(TERR(:,2)-GPS(x,2)));
[timeEnd,TERRTopLoopIndex] = min(abs(TERR(:,2)-GPS(x+loop,2)));

TERRAIN_Time = TERR(TERRBotLoopIndex:TERRTopLoopIndex,2);
TERRAIN = TERR(TERRBotLoopIndex:TERRTopLoopIndex,3);

n=round((BAROTopLoopIndex-BAROBotLoopIndex)/length(TERRAIN))

int_TERRAIN =[];
int_TERRAIN_Time =[];

for row= 1:length(TERRAIN)-1
    int_TERRAIN = [int_TERRAIN; (linspace(TERRAIN(row,:),TERRAIN(row+1,:),n))'];
    int_TERRAIN_Time = [int_TERRAIN_Time; (linspace(TERRAIN_Time(row,:),TERRAIN_Time(row+1,:),n))'];
    
end

length(BARO(BAROBotLoopIndex:BAROTopLoopIndex-1,3))
length(int_TERRAIN)

% GPS Altitude data
[timeStart,GPSBotLoopIndex] = min(abs(GPS(:,2)-GPS(x,2)));
[timeEnd,GPSTopLoopIndex] = min(abs(GPS(:,2)-GPS(x+loop,2)));

% range finder Altitude data
[timeStart,RFNDBotLoopIndex] = min(abs(RFND(:,2)-GPS(x,2)));
[timeEnd,RFNDTopLoopIndex] = min(abs(RFND(:,2)-GPS(x+loop,2)));

Clean_RFND = []
Clean_RFND = RFND(RFNDBotLoopIndex:RFNDTopLoopIndex,:)
length(Clean_RFND)

Row = 0;
while Row < length(Clean_RFND)
    Row = Row +1;
    if Clean_RFND(Row,4) < 0.011;
        Clean_RFND(Row,:)
        Clean_RFND(Row,:)= [];
        Row = Row-1
    end

end
    
length(Clean_RFND)

plot((BARO(BAROBotLoopIndex:BAROTopLoopIndex-1,2)-BARO(BAROBotLoopIndex,2))/1e6,BARO(BAROBotLoopIndex:BAROTopLoopIndex-1,3)-int_TERRAIN+7,'red')
hold on

plot((GPS(GPSBotLoopIndex:GPSTopLoopIndex,2)-GPS(GPSBotLoopIndex,2))/1e6,GPS(GPSBotLoopIndex:GPSTopLoopIndex,10),'blue')


plot((Clean_RFND(:,2)-Clean_RFND(1,2))/1e6,Clean_RFND(:,4),'yellow')

title('LIDAR,Combined Barometer & terrain Data and GPS Alttidue ')
xlabel('Time(s)')
ylabel('Acceleration of the Aircraft (ms^2)')
axis tight
hold off


hold off

