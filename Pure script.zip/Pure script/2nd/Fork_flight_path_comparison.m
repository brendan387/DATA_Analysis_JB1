
x = 1080;
loop = 193;

GPS_Lat= GPS(x:x+loop,8);  %1500 max
GPS_Lon= GPS(x:x+loop,9); %1500 max

GPS_Lat_Lon = [GPS_Lat,GPS_Lon];
GPS_Size = length(GPS_Lat_Lon)

WAY_Lat= WAY(:,1);
WAY_Lon= WAY(:,2);

% number of points to add between intial waypoint locations
WAY_Size = length(WAY);

numberofpoints = round((GPS_Size/WAY_Size)*1.5);


Improved_WAY_LAT= [];
Improved_WAY_LON= [];
t=0;

for n= 1:WAY_Size-1
    %location to add new points in matrix
    a = (n-1)*numberofpoints+1;
    b = t+numberofpoints;
    
    
    %%%% Temporay Latitude values
    %Fills in line of waypoints for lat
    LAT = linspace(WAY(n,1), WAY(n+1,1), numberofpoints); %includes start, end point and number of points to add
    Improved_WAY_LAT(a:b,1) = LAT';
      
    
    %%%% Temporay Longitudinal values
    %Fills in line of waypoints for lat
    LON = (linspace(WAY(n,2), WAY(n+1,2), numberofpoints)); %includes start, end point and number of points to add
    Improved_WAY_LON(a:b,1) = LON';
    
    %track of current location in array
    t= t+ numberofpoints;
end


WAY_Size = length(Improved_WAY)

Improved_WAY = [Improved_WAY_LAT,Improved_WAY_LON];

Course_Error = 0;

k = dsearchn(Improved_WAY,GPS_Lat_Lon(1,:))

equ_factor = round(k/(WAY_Size-GPS_Size))


for s = 1:equ_factor:k 
    Improved_WAY((s),:) = [];
end

WAY_Size = length(Improved_WAY)

Improved_WAY = [Improved_WAY(k:end,:);Improved_WAY(1:k-1,:);];

geoplot(Improved_WAY(:,1),Improved_WAY(:,2),'g-*')
hold on
for row = 1:length(GPS_Lat_Lon)

    lower = [Improved_WAY(row,:);GPS_Lat_Lon(row,:)];
    index = dsearchn(Improved_WAY,GPS_Lat_Lon((row),:));
    
    
    path = [lower];
    
    geoplot(path(:,1),path(:,2))
   
    
    Course_Error = [Course_Error;dist];
   
end

min(Course_Error);
max(Course_Error);

mean(Course_Error);
mode(Course_Error);

geoplot(GPS_Lat,GPS_Lon)
hold off

figure()
plot(Course_Error)





