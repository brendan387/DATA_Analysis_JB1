%Standard Deviation each segment

% find nearest point
TEMP_GPS = GPS_loop_2(:,1:2);
TEMP_Xt = Error_Dist(:,2);

% rearrange data so waypoint 1 is stat of gps data
k_arr = dsearchn(TEMP_GPS,WAY_MIN(1,:));
TEMP_GPS = [TEMP_GPS(k_arr:end,:);TEMP_GPS(1:k_arr,:)];
TEMP_Xt = [TEMP_Xt(k_arr:end,:);TEMP_Xt(1:k_arr,:)];

geoplot(WAY_MIN(:,1),WAY_MIN(:,2),'black --')


hold on

geoplot(TEMP_GPS(:,1),TEMP_GPS(:,2),'blue -')

Xt_WAY_COR = [];

WAY_NUM = [];

for St = 1:length(WAY_MIN)
    % k is index cloest to waypoint
    k = dsearchn(TEMP_GPS,WAY_MIN(St,:));

    Xt_temp = [TEMP_GPS(k,1:2);WAY_MIN(St,:)];
    
    geoplot(Xt_temp(:,1),Xt_temp(:,2),'red -')
    
    Xt_WAY_COR = [Xt_WAY_COR; Xt_temp];
    
    WAY_NUM = [WAY_NUM;St,k];
end

Xt_WAY=[];
radius=6371000; % radius of the earth

for St = 1:2:length(Xt_WAY_COR)
    
    
    %%% determine distance between 2 coordinates %%%
    lat1=Xt_WAY_COR(St,1)*pi/180;
    lat2=Xt_WAY_COR(St+1,1)*pi/180;
    lon1=Xt_WAY_COR(St,2)*pi/180;
    lon2=Xt_WAY_COR(St+1,2)*pi/180;
   
    deltaLat=lat2-lat1;
    deltaLon=lon2-lon1;
        
    a=sin((deltaLat)/2)^2 + cos(lat1)*cos(lat2) * sin(deltaLon/2)^2;
    c=2*atan2(sqrt(a),sqrt(1-a));
    
    Xt_WAY =[Xt_WAY;radius*c];%Haversine model based Error distance
end

STD_WAY = std(Xt_WAY)

figure
plot(WAY_MIN(:,1),WAY_MIN(:,2),'black --')

Xt_WAY = [WAY_NUM,Xt_WAY];
STD_SEG =[];

for St = 1:length(Xt_WAY)
    if St == length(Xt_WAY)
        ed = length(TEMP_Xt);
    else
        ed = WAY_NUM(St+1,2);
    end
    
    AVG_SEG= [STD_SEG,mean(TEMP_Xt(WAY_NUM(St,2):ed,:))];

end




