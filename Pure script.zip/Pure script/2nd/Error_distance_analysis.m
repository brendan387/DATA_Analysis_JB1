
minimum = min(Error_Dist(:,2))
maximum = max(Error_Dist(:,2))
avg = mean(Error_Dist(:,2))
avg2 = mode(Error_Dist(:,2))

New1 = []
New2 = []

int_Error_Dist = [];

for Row = 1:length(Error_Dist)-1
    if Error_Dist(Row,:) > 10;
       
       New1 = [New1;Error_Dist(Row,:)];
    end
    
    if Error_Dist(Row,:) > 3
       
       New2 = [New2;Error_Dist(Row,:)];
    end
    
    [timeStart,Index] = min(abs(ATT(:,2)-GPS_Time(Row,:)));
    
    %Error dist, error distance time then bearing and bearing time
    GPS_bearing(Row,:)= [Error_Dist(Row,:),GPS_Time(Row,:),ATT(Index,8),ATT(Index,2)];
    
end 

No_points_error_1 =(length(New1)/length(Error_Dist))
No_points_error_2 =(length(New2)/length(Error_Dist))

figure
plot(Error_Dist)

title('Deviation from Waypoints')
xlabel('Time(s)')
ylabel('distance from waypoint (m)')

figure


plot(GPS_bearing(:,3),GPS_bearing(:,1))

xlabel('Bearing')
ylabel('distance from waypoint (m)')
