start =  3790; %3000;
ed = 4238; %3480;

 GPS_Lat2= GPS(start:ed,9);  
 GPS_Lon2= GPS(start:ed,10);
 
 GPS_time = GPS(start:ed,2);

find_region_GPS2 = [GPS_Lat2,GPS_Lon2];





