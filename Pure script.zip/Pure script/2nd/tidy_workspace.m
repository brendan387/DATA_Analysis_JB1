


clearvars -except WAY WAY_MIN