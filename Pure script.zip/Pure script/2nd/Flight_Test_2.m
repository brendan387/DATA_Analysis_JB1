x = 2000; %prime,20'LineWidth',200 %Deprocated,1940
loop = 485; %prime,485 %Deprocated,477

GPS_Time = GPS(x:x+loop,2);

GPS_Lat= GPS(x:x+loop,8);  %1500 max
GPS_Lon= GPS(x:x+loop,9); %1500 max

GPS_Lat_Lon = [GPS_Lat,GPS_Lon];
GPS_Size = length(GPS_Lat_Lon);

WAY_Lat= WAY(:,1);
WAY_Lon= WAY(:,2);

% number of points to add between intial waypoint locations
WAY_Size = length(WAY);

numberofpoints = GPS_Size;

Improved_WAY_LAT= [];
Improved_WAY_LON= [];
Improved_WAY = [];
t=0;

for n=1:WAY_Size-1
    %location to add new points in matrix
    a = (n-1)*numberofpoints+1;
    b = t+numberofpoints;
    
    %%%% Temporay Latitude values
    %Fills in line of waypoints for Latitude
    LAT = linspace(WAY(n,1), WAY(n+1,1), numberofpoints); %includes start, end point and number of points to add
    Improved_WAY_LAT(a:b,1) = LAT';

    %%%% Temporay Longitudinal values
    %Fills in line of waypoints for long
    LON = (linspace(WAY(n,2), WAY(n+1,2), numberofpoints)); %includes start, end point and number of points to add
    Improved_WAY_LON(a:b,1) = LON';
    
    Improved_WAY = [Improved_WAY_LAT,Improved_WAY_LON];
    
    
    %track of current location in array
    t= t+ numberofpoints;
end

geoplot(WAY(:,1),WAY(:,2),'black --')
hold on
geoplot(WAY(:,1),WAY(:,2),'black o','Markersize',12)

%Rearraange waypoints to match  
k = dsearchn(Improved_WAY,GPS_Lat_Lon(1,:));
Improved_WAY = [Improved_WAY(k:end,:);Improved_WAY(1:k-1,:)];


errorCords = [];
errorPath = [];
% average radius of the Earth
radius=6371000;

Error_Dist=[];
Error_Dist_time = [];
near_Row = 0;

for Row = 1:length(GPS_Lat_Lon)
    
    Improved_WAY(1:near_Row,:)=[];
    % make sure values do not excced range of possible values
    range = near_Row+50;
    if range >= length(Improved_WAY)
        range = length(Improved_WAY);
    end
       
    
    near_Row = dsearchn(Improved_WAY(1:range,:),GPS_Lat_Lon(Row,:));
    
    errorCords = [GPS_Lat_Lon(Row,:);Improved_WAY(near_Row,:)];
    geoplot(errorCords(:,1),errorCords(:,2)) 
   
    
    
    
    %%% determine distance between 2 coordinates %%%
    lat1=errorCords(1,1)*pi/180;
    lat2=errorCords(2,1)*pi/180;
    lon1=errorCords(1,2)*pi/180;
    lon2=errorCords(2,2)*pi/180;
   
    deltaLat=lat2-lat1;
    deltaLon=lon2-lon1;
        
    a=sin((deltaLat)/2)^2 + cos(lat1)*cos(lat2) * sin(deltaLon/2)^2;
    c=2*atan2(sqrt(a),sqrt(1-a));
    
    Error_Dist =[Error_Dist;GPS_Time(Row,1),radius*c];%Haversine model based Error distance
    
    
    
end

geoplot(GPS_Lat,GPS_Lon,'blue')

figure
plot(Error_Dist(:,1),Error_Dist(:,2))