x = 2000; %prime,2000 %Deprocated,1940
loop = 485; %prime,485 %Deprocated,477

% find closest time value between gps ground speed and estimated airspeed

% cross track is Error_Dist
[timeStart,NTUNBotLoopIndex] = min(abs(NTUN(:,2)-GPS(x,2)));
[timeEnd,NTUNTopLoopIndex] = min(abs(NTUN(:,2)-GPS(x+loop,2)));

[timeStart,CTUNBotLoopIndex] = min(abs(CTUN(:,2)-GPS(x,2)));
[timeEnd,CTUNTopLoopIndex] = min(abs(CTUN(:,2)-GPS(x+loop,2)));


corr_Aspd = NTUN(NTUNBotLoopIndex+1:NTUNTopLoopIndex-1,9);


air_Speed = CTUN(CTUNBotLoopIndex:CTUNTopLoopIndex,10);

ratio = (CTUNTopLoopIndex-CTUNBotLoopIndex)/loop;

ground_Speed = [];
bearing= [];

for row=x:x+loop-1
    
    ground_Speed = [ground_Speed,linspace(GPS(row,11),GPS(row+1,11),ratio)];

end


ground_Speed = ground_Speed';

speed = [];
%ground speed
speed(:,1) = ground_Speed;
%airspeed 
speed(:,2) = CTUN(CTUNBotLoopIndex+1:CTUNTopLoopIndex-1,10);

speed(:,3) = speed(:,1)-speed(:,2);

speed(:,4) = speed(:,2)-corr_Aspd;

%ground speed
plot((GPS(x:x+loop,2)-GPS(x,2))/1e6,GPS(x:x+loop,11),'b--')
hold on

%airspeed
plot((CTUN(CTUNBotLoopIndex:CTUNTopLoopIndex,2)-GPS(x,2))/1e6,CTUN(CTUNBotLoopIndex:CTUNTopLoopIndex,10),'r--')

plot((CTUN(CTUNBotLoopIndex+1:CTUNTopLoopIndex-1,2)-GPS(x,2))/1e6,speed(:,3),'black')

plot((CTUN(CTUNBotLoopIndex+1:CTUNTopLoopIndex-1,2)-GPS(x,2))/1e6,speed(:,3),'black')

title('Wind Estimastion and GPS Speed')
xlabel('Time(s)')
ylabel('Velocity (ms)')
legend('Ground Speed from GPS','Estimated Airspeed','Estimated Wind Speed')
axis tight
hold off

figure
plot((CTUN(CTUNBotLoopIndex+1:CTUNTopLoopIndex-1,2)-GPS(x,2))/1e6,speed(:,2),'black')
hold on

plot((CTUN(CTUNBotLoopIndex+1:CTUNTopLoopIndex-1,2)-GPS(x,2))/1e6,speed(:,4),'black--')

title('Estimated Airspeed vs Recordeded Airspeed')
xlabel('Time(s)')
ylabel('Velocity (ms)')
legend('Estimated Airspeed','True Airspeed Speed')
axis tight
hold off




