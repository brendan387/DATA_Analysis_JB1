clf

load('00000006.BIN-522621.mat')

x = 910
y = 1276

geoplot(GPS(x:y,9),GPS(x:y,10))

GPS_loop_6 = [GPS(x:y,9),GPS(x:y,10)]

clearvars -except GPS_loop_1 GPS_loop_2 GPS_loop_3 GPS_loop_4 GPS_loop_5 GPS_loop_6