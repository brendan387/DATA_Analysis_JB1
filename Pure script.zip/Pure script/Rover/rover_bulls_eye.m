clf
plot(0,0,'.k','Markersize',10)
hold on
plot(ROVPAY(:,1),ROVPAY(:,2),'xk','LineWidth',2)
grid on
viscircles([0,0],0.1,'LineStyle','--','color','k');
viscircles([0,0],0.5,'LineStyle','-.','color','b');
viscircles([0,0],1,'LineStyle',':','color','r');

title('Payload Release Deviation')
xlabel('x (East-West)')
ylabel('y (North-South)')

ax = gca;
ax.FontSize = 12;

axis equal

legend('Centre','Payload Release Points')