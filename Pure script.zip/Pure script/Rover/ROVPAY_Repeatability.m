%%Repeatability
x_bar = mean(ROVPAY(:,1));
y_bar = mean(ROVPAY(:,2));

DEV_3_xs = sqrt(((ROVPAY(:,1)-x_bar).^2)+((ROVPAY(:,2)-y_bar).^2));

DEV_3_xs_bar = mean(DEV_3_xs);

STD_top =  sum((DEV_3_xs-DEV_3_xs_bar).^2);

STD = sqrt(STD_top/length(ROVPAY));

AP = sqrt((x_bar^2)+(y_bar^2))

% Repeatability
RP = DEV_3_xs_bar + 3*STD

