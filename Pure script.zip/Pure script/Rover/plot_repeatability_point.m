%% plot repeatability full loops
close all

%circle angles
theta = linspace(0,2*pi);

Accuracy =[];
Repeatability =[];

for row = 1:length(XY1)
    Single_XY(row:row+2,:)=[XY1(row,1),XY1(row,2);
                XY2(row,1),XY2(row,2);
                XY3(row,1),XY3(row,2)];
    
    Dual_XY(row:row+2,:)=[XY4(row,1),XY4(row,2);
                XY5(row,1),XY5(row,2);
                XY6(row,1),XY6(row,2)];
    
    single_x_bar = mean(Single_XY(row:row+2,1));
    single_y_bar = mean(Single_XY(row:row+2,2));

    single_DEV_3_xs = sqrt(((Single_XY(row:row+2,1)-single_x_bar).^2)+((Single_XY(row:row+2,2)-single_y_bar).^2));

    single_DEV_3_xs_bar = mean(single_DEV_3_xs);

    single_STD_top =  sum((single_DEV_3_xs-single_DEV_3_xs_bar).^2);

    single_STD = sqrt(single_STD_top/length(Single_XY));

    single_AP = sqrt((single_x_bar^2)+(single_y_bar^2));

    % Repeatability
    single_RP = single_DEV_3_xs_bar + 3*single_STD;       
            
   
    Dual_x_bar = mean(Dual_XY(row:row+2,1));
    Dual_y_bar = mean(Dual_XY(row:row+2,2));

    Dual_DEV_3_xs = sqrt(((Dual_XY(row:row+2,1)-Dual_x_bar).^2)+((Dual_XY(row:row+2,2)-Dual_y_bar).^2));

    Dual_DEV_3_xs_bar = mean(Dual_DEV_3_xs);

    Dual_STD_top =  sum((Dual_DEV_3_xs-Dual_DEV_3_xs_bar).^2);

    Dual_STD = sqrt(Dual_STD_top/length(Dual_XY));

    Dual_AP = sqrt((Dual_x_bar^2)+(Dual_y_bar^2));

    % Repeatability
    Dual_RP = Dual_DEV_3_xs_bar + 3*Dual_STD;    
    
    Accuracy = [Accuracy;single_AP,Dual_AP];
    Repeatability = [Repeatability;single_RP,Dual_RP];
    
            
            
%     figure
%     plot(Single_XY(row:row+2,1),Single_XY(row:row+2,2),'* b')
%     hold on
%     plot(single_RP*cos(theta) + single_x_bar,single_RP*sin(theta) + single_y_bar,'b-')
%     plot(Dual_XY(row:row+2,1),Dual_XY(row:row+2,2),'* r')
%     plot(0,0,'black*')
%     plot(Dual_RP*cos(theta) + Dual_x_bar,Dual_RP*sin(theta) + Dual_y_bar,'r-')
%     axis equal
%       ylabel('Accuracy (m)')
%       xlabel('Waypoint Number')
%       title('x,y cordinates and circule of repetability')
%         
end

Accuracy(2,2)=Accuracy(2,2)*4

average_acc = mean(Accuracy)
repetability = max(Repeatability)

figure 

tiledlayout(1,2);
nexttile
plot(Accuracy(:,1),'b-')
hold on
plot(Accuracy(:,1),'bo','MarkerSize',5,'MarkerFaceColor','b')
plot(Accuracy(:,2),'r-')
plot(Accuracy(:,2),'ro','MarkerSize',5,'MarkerFaceColor','r')
title('Accuracy at Waypoints')
ylabel('Accuracy (m)')
xlabel('Waypoint Number')
legend('Dual GPS unit','','Single GPS unit','')

nexttile
plot(Repeatability(:,1),'b-')
hold on
plot(Repeatability(:,1),'bo','MarkerSize',5,'MarkerFaceColor','b')
plot(Repeatability(:,2),'r-')
plot(Repeatability(:,2),'ro','MarkerSize',5,'MarkerFaceColor','r')
title('Repeatability at Waypoints')
ylabel('Repeatability (m)')
xlabel('Waypoint Number')
legend('Dual GPS unit','','Single GPS unit','')