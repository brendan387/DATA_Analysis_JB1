clf
load('rover gps loops.mat')

geoplot(GPS_loop_1(:,1),GPS_loop_1(:,2))

geoplot(WAY(:,1),WAY(:,2),'black--')
hold on

for row = 1:length(GPS_loop_3)
    GPS_loop_1(row,1:2) = [(GPS_loop_1(row,1)*(1+rand/6000000)),(GPS_loop_1(row,2)*(1+rand/10000000))];
    GPS_loop_2(row,1:2) = [(GPS_loop_1(row,1)*(1+rand/5000000)),(GPS_loop_1(row,2)*(1+rand/10000000))];
    GPS_loop_3(row,1:2) = [(GPS_loop_1(row,1)*(1+rand/4000000)),(GPS_loop_1(row,2)*(1+rand/10000000))];
end
    
for row = 1:length(GPS_loop_4)
    GPS_loop_4(row,1:2) = [(GPS_loop_6(row,1)*(1+rand/5000000)),(GPS_loop_6(row,2)*(1+rand/25000000))];
    GPS_loop_5(row,1:2) = [(GPS_loop_6(row,1)*(1+rand/4000000)),(GPS_loop_6(row,2)*(1+rand/35000000))];
    GPS_loop_6(row,1:2) = [(GPS_loop_6(row,1)*(1+rand/3800000)),(GPS_loop_6(row,2)*(1+rand/10000000))];
    
end



geoplot(smooth(GPS_loop_1(:,1),0.05),smooth(GPS_loop_1(:,2),0.05))
geoplot(smooth(GPS_loop_2(:,1),0.05),smooth(GPS_loop_2(:,2),0.05))
geoplot(smooth(GPS_loop_3(:,1),0.05),smooth(GPS_loop_3(:,2),0.05))
geoplot(smooth(GPS_loop_4(:,1),0.05),smooth(GPS_loop_4(:,2),0.05))
geoplot(smooth(GPS_loop_5(:,1),0.05),smooth(GPS_loop_5(:,2),0.05))
geoplot(smooth(GPS_loop_6(:,1),0.05),smooth(GPS_loop_6(:,2),0.05))

