
geoplot(GPS_loop_1(:,1),GPS_loop_1(:,2))
hold on
geoplot(GPS_loop_2(:,1),GPS_loop_2(:,2))
geoplot(GPS_loop_3(:,1),GPS_loop_3(:,2))

geoplot(GPS_loop_6(:,1),GPS_loop_6(:,2))