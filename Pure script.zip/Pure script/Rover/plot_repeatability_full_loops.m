%% plot repeatability full loops

plot(XY1(:,1),XY1(:,2),'* b')
hold on
plot(XY2(:,1),XY2(:,2),'* b')
plot(XY3(:,1),XY3(:,2),'* b')
plot(0,0,'black*')



figure
plot(XY4(:,1),XY4(:,2),'* g')
hold on
plot(XY5(:,1),XY5(:,2),'* g')
plot(XY6(:,1),XY6(:,2),'* g')
plot(0,0,'black*')
